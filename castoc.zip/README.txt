UCAS/UTOC Packing Tool (v1.3) by Gimmicking


<<----- INSTRUCTIONS FOR USING THE TOOL ----->>


Step 1: Create Manifest File

	1. Place the .ucas and .utoc files in the _INPUT folder
	2. Run the CREATEMANIFEST.bat file
	3. Wait for the CMD window to say "Press any key to continue..."
	4. There should be a Manifest.json file in the main folder now (You do not need to do anything with this file)
	NOTE: You can always make a new .manifest file by placing a new .ucas/.utoc file in the _INPUT folder and running the CREATEMANIFEST.bat file again. 
	NOTE: The master folder holds the _INPUT, _OUTPUT, _EDIT, and Source folders. 

Step 2: Unpack the .ucas/.utoc files.

	1. Place the UCAS and UTOC file in the _INPUT folder. 
	2. Run the batch file UNPACKFILES.bat (You may get a warning, but you can ignore this). 
	3. Wait for the CMD window to say "Press any key to continue..."
	4. Output files will be in the _EDIT folder. 

Step 3: Pack the modified files. 

	1. Place ALL modified .uasset files in their original file locations and in their original folder structure.
	2. With all the modified files and directories in the _EDIT folder, run PACKFILES.bat. 
	3. Wait for the CMD window to say "Press any key to continue..."
	4. Your modified .ucas/.utoc/.pak file will be in the _OUTPUT folder. 
	NOTE: The .ucas and .utoc can be renamed, but they must have the same name for them to work in the game. They 
		also must have a _P at the end of their name, so they take priority
	NOTE: There can be MORE THAN ONE .pak/.ucas/.utoc file in the same folder, and they will both run at the same 
		time. They just must have different names and they must still end in _P


<<----- CREDITS ----->>


The Main.exe program and programming language is based off of 
this tool: https://github.com/gitMenv/UEcastoc

The Manifest.json tool would not be possible without the help of Bivi#2020 
on Hocotate Hacker Discord: https://github.com/190nm/UEcastoc/releases/tag/v1.0.2

The UAsset packing portion of this tool was originally uploaded 
to the Hocotate Hacker Discord by BreakfastBrainz2#0636

My Youtube channel for Pikmin mods and other stuff: https://www.youtube.com/@Gimmicking
My name is Gimmicking#5602 on Discord, and I am also in the Hocotate Hacker Discord

Other Pikmin 4 Tools: https://gamebanana.com/tools/cats/1574